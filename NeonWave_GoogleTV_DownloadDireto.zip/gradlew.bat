@echo off
rem Neon Wave project Gradle launcher. Requires Java/JDK on this machine.
setlocal
set "APP_HOME=%~dp0"
cd /d "%APP_HOME%"
if defined JAVA_HOME (
  set "JAVA_CMD=%JAVA_HOME%\bin\java.exe"
) else (
  set "JAVA_CMD=java.exe"
)
"%JAVA_CMD%" -jar "%APP_HOME%gradle\wrapper\gradle-bootstrap.jar" %*
exit /b %ERRORLEVEL%
