# Neon Wave — projeto Android nativo

Projeto Android em Kotlin, Jetpack Compose e AndroidX Media3.

## Recursos incluídos nesta versão

- Varredura da biblioteca do aparelho usando o catálogo de mídia do Android, incluindo músicas e vídeos MP4.
- Solicitação de permissão de acesso à mídia e botão para atualizar a biblioteca.
- Tela inicial de carregamento animada.
- Biblioteca com título e artista; a arte da faixa é exibida quando o Android disponibiliza uma miniatura/capa para o arquivo.
- Tela “Tocando agora” com capa quadrada central, título, artista, anterior/próxima, reproduzir/pausar, aleatório e modos de repetição (desligado, repetir fila e repetir faixa).
- Playlists criadas pelo usuário, com os itens guardados localmente entre sessões.
- Ações para adicionar uma faixa a uma playlist.
- Reordenação da fila com setas para cima/baixo.
- Configurações de papel de parede, seleção de imagem e ajuste de opacidade.
- Serviço Media3 de reprodução em primeiro plano para manter a reprodução quando o app fica em segundo plano, com controles de mídia do Android.
- Mantidos os ícones e a identidade visual Neon Wave.

## Compilação

A raiz contém `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.properties` e o bootstrapper local usado para obter Gradle 8.9. O projeto usa Android Gradle Plugin 8.7.3, Kotlin 2.0.21 e Java 17.

Na raiz do projeto, use:

```sh
./gradlew assembleDebug
```

O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk` se a compilação terminar com sucesso. Para gerar uma versão release assinada, configure um keystore e use as opções de assinatura da IDE.

## Observações importantes

- Este ambiente de edição não tem Android SDK configurado, portanto não foi possível executar uma compilação Android completa nem validar o APK final. Não considere o ZIP como um APK já testado.
- A primeira compilação precisa de internet para obter Gradle e as dependências, e a IDE precisa fornecer o Android SDK e um JDK compatível (JDK 17 recomendado).
- A capa depende dos metadados/miniaturas que o Android consegue obter do arquivo. Arquivos sem arte embutida ou sem miniatura podem mostrar o ícone musical padrão.
- Para procurar arquivos, o app usa o índice de mídia do Android (MediaStore); arquivos que ainda não foram indexados pelo sistema podem só aparecer depois de atualizar/reiniciar a indexação do dispositivo.
- As playlists guardam referências aos arquivos locais. Se um arquivo for apagado ou movido, ele pode deixar de abrir.


## Identificador do aplicativo

O identificador Android (applicationId) e o namespace são `com.megzin.neonwave`.
