package com.megzin.neonwave

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun LyricsScreen(title: String, artist: String, artworkUrl: String?, lyrics: String?, onAddLyrics: () -> Unit, onSearchWeb: () -> Unit) {
    Box(Modifier.fillMaxSize().background(LyricsWine)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            MiniPlayer(title, artist, artworkUrl, false, {}, {}, {})
            if (lyrics.isNullOrBlank()) Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.FormatQuote, null, tint = Color.White.copy(alpha = .28f), modifier = Modifier.size(58.dp))
                Spacer(Modifier.height(8.dp)); Text("Sem letras", color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.titleMedium)
            } else Text(lyrics, Modifier.weight(1f).fillMaxWidth().padding(top = 24.dp), color = Color.White, style = MaterialTheme.typography.bodyLarge)
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onAddLyrics, shape = CircleShape, modifier = Modifier.size(56.dp), contentPadding = PaddingValues(0.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White)) { Text("+", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
            FloatingActionButton(onClick = onSearchWeb, containerColor = Color.White, contentColor = LyricsWine) { Icon(Icons.Default.Search, "Pesquisar letras") }
        }
    }
}
