package com.megzin.neonwave

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun MiniPlayer(
    title: String, artist: String, artworkUrl: String?, isPlaying: Boolean,
    onPlayPause: () -> Unit, onLoop: () -> Unit, onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onOpen() }, color = NeonSurface, tonalElevation = 8.dp) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AsyncImage(model = artworkUrl, contentDescription = "Capa de $title", modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(NeonBackground), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(artist, color = NeonMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton(onClick = onLoop) { Icon(Icons.Default.Loop, contentDescription = "Repetir", tint = NeonPurple) }
            IconButton(onClick = onPlayPause) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isPlaying) "Pausar" else "Reproduzir", tint = NeonCyan) }
        }
    }
}
