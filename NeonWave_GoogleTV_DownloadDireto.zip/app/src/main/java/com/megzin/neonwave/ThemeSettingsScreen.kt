package com.megzin.neonwave

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ThemeSettingsScreen(onAccentSelected: (Color) -> Unit = {}) {
    var mode by remember { mutableStateOf("Escuro") }
    var accent by remember { mutableStateOf(NeonCyan) }
    val accents = listOf(NeonCyan, NeonPurple, NeonBlue, Color(0xFFFF4D9D), Color(0xFFFFB020), Color(0xFF4ADE80))
    Column(Modifier.fillMaxSize().background(NeonBackground).padding(20.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Text("PERSONALIZAR TEMA", color = NeonCyan, style = MaterialTheme.typography.titleLarge)
        Text("Aparência", color = Color.White, style = MaterialTheme.typography.titleMedium)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("Escuro", "Claro", "Sistema").forEachIndexed { i, label ->
                SegmentedButton(selected = mode == label, onClick = { mode = label }, shape = SegmentedButtonDefaults.itemShape(i, 3)) { Text(label) }
            }
        }
        Text("Cor de destaque", color = Color.White, style = MaterialTheme.typography.titleMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(accents) { color ->
                Box(Modifier.size(if (accent == color) 46.dp else 40.dp).clip(CircleShape).background(color).clickable { accent = color; onAccentSelected(color) }, contentAlignment = Alignment.Center) {
                    if (accent == color) Text("✓", color = Color.Black, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        Text("Tema escolhido: $mode", color = NeonMuted, style = MaterialTheme.typography.bodySmall)
    }
}
