package com.megzin.neonwave

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun TrackListItem(title: String, artist: String, artworkUrl: String?, hasLyrics: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        AsyncImage(model = artworkUrl, contentDescription = "Capa de $title", modifier = Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(NeonSurface), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, color = NeonMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (hasLyrics) Surface(color = Color.Transparent, shape = RoundedCornerShape(6.dp), border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan)) { Text("LETRA", Modifier.padding(horizontal = 7.dp, vertical = 4.dp), color = NeonCyan, style = MaterialTheme.typography.labelSmall) }
    }
}
