package com.megzin.neonwave

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonBackground = Color(0xFF0A0A0F)
val NeonSurface = Color(0xFF15151F)
val NeonCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFF8A2BE2)
val NeonBlue = Color(0xFF3B82F6)
val NeonMuted = Color(0xFFA1A1AA)
val LyricsWine = Color(0xFF2A1A1E)

private val NeonDarkScheme = darkColorScheme(
    primary = NeonCyan, secondary = NeonPurple, tertiary = NeonBlue,
    background = NeonBackground, surface = NeonSurface,
    onPrimary = NeonBackground, onSecondary = Color.White,
    onBackground = Color.White, onSurface = Color.White
)

@Composable
fun NeonWaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NeonDarkScheme, content = content)
}
