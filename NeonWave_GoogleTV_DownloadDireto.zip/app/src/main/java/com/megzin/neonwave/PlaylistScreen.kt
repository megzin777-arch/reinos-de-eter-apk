package com.megzin.neonwave

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

data class PlaylistUiModel(val name: String, val songs: List<String>, val artworkUrl: String? = null)

@Composable
fun PlaylistScreen(playlists: List<PlaylistUiModel>, onCreate: () -> Unit, onOpen: (PlaylistUiModel) -> Unit) {
    Column(Modifier.fillMaxSize().background(NeonBackground).padding(top = 16.dp)) {
        Text("PLAYLISTS", Modifier.padding(horizontal = 18.dp, vertical = 10.dp), color = NeonCyan, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Surface(onClick = onCreate, color = Color.Transparent, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, NeonPurple), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Add, null, tint = NeonCyan); Spacer(Modifier.width(12.dp)); Text("Adicionar nova playlist", color = Color.White, fontWeight = FontWeight.SemiBold) } } }
            items(playlists.size) { i ->
                val playlist = playlists[i]
                Surface(onClick = { onOpen(playlist) }, color = NeonSurface, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(model = playlist.artworkUrl, contentDescription = "Capa ${playlist.name}", modifier = Modifier.size(76.dp).clip(RoundedCornerShape(14.dp)).background(NeonBackground), contentScale = ContentScale.Crop)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(playlist.name, color = Color.White, fontWeight = FontWeight.Bold)
                            playlist.songs.take(2).forEach { song -> Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.MusicNote, null, tint = NeonCyan, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text(song, color = NeonMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1) } }
                        }
                        Text("${playlist.songs.size}", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
