package com.megzin.neonwave

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun PlayerScreen(
    title: String = "Midnight City", artist: String = "M83", artworkUrl: String? = null,
    onBack: () -> Unit = {}, onSettings: () -> Unit = {}, onLyrics: () -> Unit = {},
    onEqualizer: () -> Unit = {}, onPrevious: () -> Unit = {}, onNext: () -> Unit = {},
    onNavigate: (String) -> Unit = {}
) {
    var playing by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0.36f) }
    Column(Modifier.fillMaxSize().background(NeonBackground)) {
        Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(NeonCyan, NeonPurple))), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = NeonBackground) }
            Spacer(Modifier.width(10.dp))
            Text("NEON WAVE", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Configurações", tint = NeonMuted) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = NeonCyan) }
            Text("TOCANDO AGORA", color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            AsyncImage(model = artworkUrl, contentDescription = "Capa do álbum de $title", modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp)).background(NeonSurface), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(22.dp))
            Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text(artist, color = NeonCyan, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(18.dp))
            Slider(value = progress, onValueChange = { progress = it }, colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan, inactiveTrackColor = Color(0xFF30303A)), modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("1:24", color = NeonMuted, style = MaterialTheme.typography.labelSmall); Text("3:54", color = NeonMuted, style = MaterialTheme.typography.labelSmall) }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onLyrics, modifier = Modifier.weight(1f), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan)) { Icon(Icons.Default.Lyrics, null, tint = NeonCyan); Spacer(Modifier.width(7.dp)); Text("Letras", color = NeonCyan) }
                OutlinedButton(onClick = onEqualizer, modifier = Modifier.weight(1f), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple)) { Icon(Icons.Default.Equalizer, null, tint = NeonPurple); Spacer(Modifier.width(7.dp)); Text("Equalizador", color = NeonPurple, maxLines = 1) }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { shuffle = !shuffle }) { Icon(Icons.Default.Shuffle, "Aleatório", tint = if (shuffle) NeonCyan else NeonMuted) }
                IconButton(onClick = { repeat = !repeat }) { Icon(Icons.Default.Repeat, "Repetir", tint = if (repeat) NeonCyan else NeonMuted) }
                IconButton(onClick = onPrevious, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = Color.White, modifier = Modifier.size(32.dp)) }
                IconButton(onClick = { playing = !playing }, modifier = Modifier.size(68.dp).clip(CircleShape).background(Brush.linearGradient(listOf(NeonBlue, NeonPurple)))) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pausar" else "Reproduzir", tint = Color.White, modifier = Modifier.size(38.dp)) }
                IconButton(onClick = onNext, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.SkipNext, "Próxima", tint = Color.White, modifier = Modifier.size(32.dp)) }
                Spacer(Modifier.width(2.dp))
            }
        }
        NavigationBar(containerColor = NeonSurface, contentColor = NeonMuted) {
            listOf(Triple("Músicas", Icons.Default.LibraryMusic, "music"), Triple("Playlists", Icons.Default.QueueMusic, "playlists"), Triple("Player", Icons.Default.GraphicEq, "player")).forEach { (label, icon, route) ->
                NavigationBarItem(selected = route == "player", onClick = { onNavigate(route) }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = NeonCyan, selectedTextColor = NeonCyan, indicatorColor = NeonCyan.copy(alpha = .12f), unselectedIconColor = NeonMuted, unselectedTextColor = NeonMuted))
            }
        }
    }
}
