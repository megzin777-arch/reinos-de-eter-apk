package com.megzin.neonwave

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.audiofx.AudioEffect
import android.provider.DocumentsContract
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executor
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Night = Color(0xFF0A0A0F)
private val Panel = Color(0xFF15151F)
private val Cyan = Color(0xFF00E5FF)
private val Purple = Color(0xFF8A2BE2)

private data class Track(val title: String, val artist: String, val uri: Uri, val video: Boolean = false) {
    fun mediaItem(): MediaItem = MediaItem.Builder().setUri(uri).setMediaMetadata(
        MediaMetadata.Builder().setTitle(title).setArtist(artist).setDisplayTitle(title).build()
    ).build()
}

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val controllerState = mutableStateOf<MediaController?>(null)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ try { controllerState.value = controllerFuture?.get() } catch (_: Exception) {} }, Executor { it.run() })
        setContent { NeonWaveScreen(controllerState.value, ::scanMedia) }
    }
    private fun scanMedia(): List<Track> {
        val result = mutableListOf<Track>()
        val audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val audioProjection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        contentResolver.query(audioUri, audioProjection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) { val id = c.getLong(idCol); val title = c.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Música sem título"; val artist = c.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Artista desconhecido"; result.add(Track(title, artist, Uri.withAppendedPath(audioUri, id.toString()))) }
        }
        val videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val videoProjection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.MIME_TYPE)
        contentResolver.query(videoUri, videoProjection, "${MediaStore.Video.Media.MIME_TYPE} = ?", arrayOf("video/mp4"), "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            while (c.moveToNext()) { val id = c.getLong(idCol); val title = c.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Vídeo MP4"; result.add(Track(title, "Vídeo", Uri.withAppendedPath(videoUri, id.toString()), true)) }
        }
        return result.distinctBy { it.uri }.sortedBy { it.title.lowercase() }
    }
    override fun onDestroy() { controllerFuture?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

private fun findLocalLyrics(context: Context, track: Track): String? {
    // Procura arquivos .lrc/.txt indexados no armazenamento usando o nome da faixa.
    val base = track.title.substringBeforeLast('.', track.title).trim().lowercase()
    val projection = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME)
    val uri = MediaStore.Files.getContentUri("external")
    return try {
        context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            val nameCol = c.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val idCol = c.getColumnIndex(MediaStore.Files.FileColumns._ID)
            while (c.moveToNext()) {
                val name = c.getString(nameCol) ?: continue
                val lower = name.lowercase()
                if ((lower.endsWith(".lrc") || lower.endsWith(".txt")) && lower.substringBeforeLast('.').trim() == base) {
                    val fileUri = Uri.withAppendedPath(uri, c.getLong(idCol).toString())
                    val text = context.contentResolver.openInputStream(fileUri)?.bufferedReader()?.use { it.readText() }?.trim()
                    if (!text.isNullOrBlank()) return text
                }
            }
            null
        }
    } catch (_: Exception) { null }
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(total / 60L, total % 60L)
}

private fun findOnlineLyrics(context: Context, track: Track): String? {
    val prefs = context.getSharedPreferences("lyrics_cache", Context.MODE_PRIVATE)
    val key = (track.title + "|" + track.artist).lowercase()
    prefs.getString(key, null)?.takeIf { it.isNotBlank() }?.let { return it }
    fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
    fun request(path: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL("https://lrclib.net/api/$path").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 5000; readTimeout = 5000
                setRequestProperty("User-Agent", "NeonWave/1.0 (Android music player)")
            }
            if (connection.responseCode !in 200..299) return null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            (json.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                ?: json.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" })
        } catch (_: Exception) { null } finally { connection?.disconnect() }
    }
    val exact = request("get?track_name=${enc(track.title)}&artist_name=${enc(track.artist)}")
    val found = exact ?: run {
        val results = try {
            var c: HttpURLConnection? = null
            try {
                c = (URL("https://lrclib.net/api/search?track_name=${enc(track.title)}&artist_name=${enc(track.artist)}").openConnection() as HttpURLConnection).apply { connectTimeout = 5000; readTimeout = 5000; setRequestProperty("User-Agent", "NeonWave/1.0 (Android music player)") }
                if (c.responseCode in 200..299) JSONArray(c.inputStream.bufferedReader().use { it.readText() }) else JSONArray()
            } finally { c?.disconnect() }
        } catch (_: Exception) { JSONArray() }
        (0 until results.length()).asSequence().mapNotNull { i ->
            val item = results.optJSONObject(i) ?: return@mapNotNull null
            item.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                ?: item.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
        }.firstOrNull()
    }
    if (!found.isNullOrBlank()) prefs.edit().putString(key, found).apply()
    return found
}

@Composable
private fun NeonWaveScreen(controller: MediaController?, scanMedia: () -> List<Track>) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("neon_settings", Context.MODE_PRIVATE) }
    var loading by remember { mutableStateOf(true) }
    var permissionScanTick by remember { mutableIntStateOf(0) }
    var allTracks by remember { mutableStateOf(emptyList<Track>()) }
    var queue by remember { mutableStateOf(emptyList<Track>()) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var currentScreen by remember { mutableStateOf("home") }
    var playing by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var wallpaper by remember { mutableStateOf(prefs.getString("wallpaper", null)?.let(Uri::parse)) }
    var wallpaperOpacity by remember { mutableFloatStateOf(prefs.getFloat("wallpaper_opacity", 0.22f)) }
    var playlistNames by remember { mutableStateOf(run {
        val saved = prefs.getString("playlist_names", null)
        if (saved == null) listOf("Todas as músicas") else try { val arr = JSONArray(saved); (0 until arr.length()).map { arr.getString(it) }.let { if ("Todas as músicas" in it) it else listOf("Todas as músicas") + it } } catch (_: Exception) { listOf("Todas as músicas") }
    }) }
    var selectedPlaylist by remember { mutableStateOf("Todas as músicas") }
    var musicSearch by remember { mutableStateOf("") }
    var lyricsSearching by remember { mutableStateOf(false) }
    var playlists by remember { mutableStateOf<Map<String, List<String>>>(run {
        try { val obj = JSONObject(prefs.getString("playlists", "{}") ?: "{}"); val map = mutableMapOf<String, List<String>>(); val keys = obj.keys(); while (keys.hasNext()) { val k = keys.next(); val arr = obj.getJSONArray(k); map[k] = (0 until arr.length()).map { arr.getString(it) } }; map.toMap() } catch (_: Exception) { emptyMap<String, List<String>>() }
    }) }
    var showNewPlaylist by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showPlaylistMenu by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    var trackForPlaylist by remember { mutableStateOf<Track?>(null) }
    var artwork by remember { mutableStateOf<Bitmap?>(null) }
    var lyricsText by remember { mutableStateOf<String?>(null) }
    var showLyrics by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var showEqualizerInfo by remember { mutableStateOf(false) }

    val permissions = remember { if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        if (results.values.any { it }) { loading = true; permissionScanTick++ }
    }
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; wallpaper = uri; prefs.edit().putString("wallpaper", uri.toString()).apply() }
    }

    LaunchedEffect(Unit) {
        val granted = permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (!granted) permissionLauncher.launch(permissions)
        withContext(Dispatchers.IO) { delay(750); scanMedia() }.also { allTracks = it; queue = it }
        loading = false
    }
    LaunchedEffect(permissionScanTick) {
        if (permissionScanTick > 0) {
            loading = true
            val scanned = withContext(Dispatchers.IO) { scanMedia() }
            allTracks = scanned
            if (selectedPlaylist == "Todas as músicas") queue = scanned
            loading = false
        }
    }
    LaunchedEffect(playlistNames, playlists) {
        prefs.edit().putString("playlist_names", JSONArray(playlistNames.filter { it != "Todas as músicas" }).toString()).apply()
        val obj = JSONObject(); playlists.forEach { (name, uris) -> obj.put(name, JSONArray(uris)) }; prefs.edit().putString("playlists", obj.toString()).apply()
    }
    LaunchedEffect(controller, queue) {
        if (controller != null && queue.isNotEmpty() && controller.mediaItemCount == 0) { controller.setMediaItems(queue.map { it.mediaItem() }); controller.prepare() }
    }
    LaunchedEffect(controller) {
        while (true) {
            if (controller != null) {
                playing = controller.isPlaying
                shuffle = controller.shuffleModeEnabled
                repeatMode = controller.repeatMode
                positionMs = controller.currentPosition.coerceAtLeast(0L)
                durationMs = controller.duration.takeIf { it > 0L && it != androidx.media3.common.C.TIME_UNSET } ?: 0L
                if (controller.mediaItemCount > 0) currentIndex = controller.currentMediaItemIndex.coerceIn(0, maxOf(0, queue.lastIndex))
            }
            delay(400)
        }
    }
    val currentTrack = queue.getOrNull(currentIndex)
    LaunchedEffect(currentTrack?.uri) {
        lyricsText = null
        artwork = null
        val track = currentTrack ?: return@LaunchedEffect
        artwork = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(track.uri, android.util.Size(600, 600), null)
                else { val retriever = MediaMetadataRetriever(); retriever.setDataSource(context, track.uri); val bmp = retriever.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) } ?: retriever.frameAtTime; retriever.release(); bmp }
            } catch (_: Exception) { null }
        }
        lyricsText = withContext(Dispatchers.IO) { findLocalLyrics(context, track) ?: findOnlineLyrics(context, track) }
    }
    fun playList(list: List<Track>, start: Int = 0) {
        if (list.isEmpty()) return
        queue = list; currentIndex = start.coerceIn(0, list.lastIndex)
        controller?.setMediaItems(list.map { it.mediaItem() }, currentIndex, 0L); controller?.prepare(); controller?.play()
    }
    fun reorder(from: Int, to: Int) {
        if (from !in queue.indices || to !in queue.indices || from == to) return
        val mutable = queue.toMutableList(); val item = mutable.removeAt(from); mutable.add(to, item); queue = mutable
        if (controller != null) { val oldUri = currentTrack?.uri; controller.setMediaItems(queue.map { it.mediaItem() }); val newIndex = queue.indexOfFirst { it.uri == oldUri }.coerceAtLeast(0); controller.seekToDefaultPosition(newIndex); currentIndex = newIndex; controller.prepare(); if (playing) controller.play() }
    }
    val playlistTracks = if (selectedPlaylist == "Todas as músicas") allTracks else allTracks.filter { playlists[selectedPlaylist]?.contains(it.uri.toString()) == true }
    val visibleTracks = playlistTracks.filter { musicSearch.isBlank() || it.title.contains(musicSearch, true) || it.artist.contains(musicSearch, true) }

    MaterialTheme(colorScheme = darkColorScheme(background = Night, surface = Panel, primary = Cyan, secondary = Purple)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11111D), Night, Color(0xFF130D20))))) {
            if (wallpaper != null) {
                var wallpaperBitmap by remember(wallpaper) { mutableStateOf<Bitmap?>(null) }
                LaunchedEffect(wallpaper) { wallpaperBitmap = withContext(Dispatchers.IO) { try { context.contentResolver.openInputStream(wallpaper!!)?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null } } }
                wallpaperBitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = wallpaperOpacity) }
            }
            if (loading) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11111D), Night, Color(0xFF130D20)))), contentAlignment = Alignment.Center) {
                    val transition = rememberInfiniteTransition(label = "loading")
                    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "rotation")
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(112.dp).clip(RoundedCornerShape(32.dp)).background(Brush.linearGradient(listOf(Cyan, Purple))), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Night, modifier = Modifier.size(65.dp).rotate(rotation)) }
                        Spacer(Modifier.height(24.dp)); Text("NEON WAVE", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Spacer(Modifier.height(8.dp)); Text("Procurando suas músicas...", color = Cyan, fontSize = 13.sp)
                        Spacer(Modifier.height(22.dp)); CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp, modifier = Modifier.size(30.dp))
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Cyan, Purple))), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Night, modifier = Modifier.size(28.dp)) }
                        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("NEON WAVE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("seu som, outra dimensão", color = Cyan, fontSize = 11.sp) }
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Configurações", tint = Cyan) }
                    }
                    Spacer(Modifier.height(14.dp))
                    if (currentScreen == "player") {
                        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { currentScreen = "home" }) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }; Text("TOCANDO AGORA", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.fillMaxWidth(0.78f).aspectRatio(1f).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF1A3152), Color(0xFF24133F)))), contentAlignment = Alignment.Center) {
                                    if (artwork != null) Image(artwork!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Icon(Icons.Default.Album, null, tint = Cyan, modifier = Modifier.size(100.dp))
                                }
                                Spacer(Modifier.height(24.dp)); Text(currentTrack?.title ?: "Nenhuma música", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(currentTrack?.artist ?: "Escolha uma música", color = Cyan, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(12.dp))
                                Slider(value = if (durationMs > 0L) positionMs.coerceIn(0L, durationMs).toFloat() else 0f,
                                    onValueChange = { positionMs = it.toLong() },
                                    onValueChangeFinished = { if (durationMs > 0L) controller?.seekTo(positionMs.coerceIn(0L, durationMs)) },
                                    valueRange = 0f..(durationMs.coerceAtLeast(1L).toFloat()),
                                    enabled = durationMs > 0L,
                                    colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color.DarkGray))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(formatTime(positionMs), color = Color.LightGray, fontSize = 11.sp)
                                    Text(formatTime(durationMs), color = Color.LightGray, fontSize = 11.sp)
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                                    OutlinedButton(onClick = { showLyrics = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(6.dp)); Text("Letras") }
                                    Spacer(Modifier.width(10.dp))
                                    OutlinedButton(onClick = {
                                        val sessionId = context.getSharedPreferences("neon_audio", Context.MODE_PRIVATE).getInt("audio_session_id", 0)
                                        val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
                                            putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                                            putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
                                            putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
                                        }
                                        try { context.startActivity(intent) } catch (_: Exception) { showEqualizerInfo = true }
                                    }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Purple)) { Icon(Icons.Default.Equalizer, null); Spacer(Modifier.width(6.dp)); Text("Equalizador") }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle }) { Icon(Icons.Default.Shuffle, "Aleatório", tint = if (shuffle) Cyan else Color.LightGray, modifier = Modifier.size(26.dp)) }
                                    IconButton(onClick = { repeatMode = when (repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }; controller?.repeatMode = repeatMode }) { Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Repetir", tint = if (repeatMode != Player.REPEAT_MODE_OFF) Cyan else Color.LightGray, modifier = Modifier.size(27.dp)) }
                                    IconButton(onClick = { controller?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = Color.White, modifier = Modifier.size(36.dp)) }
                                    IconButton(onClick = { if (playing) controller?.pause() else controller?.play() }, modifier = Modifier.size(66.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Cyan, Purple)))) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Night, modifier = Modifier.size(42.dp)) }
                                    IconButton(onClick = { controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Próxima", tint = Color.White, modifier = Modifier.size(36.dp)) }
                                }
                                Text(when (repeatMode) { Player.REPEAT_MODE_ONE -> "Repetindo esta música"; Player.REPEAT_MODE_ALL -> "Repetindo a fila"; else -> if (shuffle) "Modo aleatório ativo" else "Reprodução normal" }, color = Color.LightGray, fontSize = 12.sp)
                            }
                        }
                    } else if (currentScreen == "playlists") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("SUAS PLAYLISTS", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
                            FilledTonalButton(onClick = { showNewPlaylist = true }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF183747), contentColor = Cyan)) { Icon(Icons.Default.Add, null); Text("Nova") }
                        }
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            itemsIndexed(playlistNames, key = { _, name -> name }) { _, name ->
                                val count = if (name == "Todas as músicas") allTracks.size else (playlists[name]?.size ?: 0)
                                Card(Modifier.fillMaxWidth().clickable { selectedPlaylist = name; currentScreen = "home" }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Cyan.copy(alpha = 0.85f), Purple))), contentAlignment = Alignment.Center) {
                                            Icon(if (name == "Todas as músicas") Icons.Default.LibraryMusic else Icons.Default.QueueMusic, null, tint = Night, modifier = Modifier.size(32.dp))
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.Bold); Text("$count faixas", color = Color.LightGray, fontSize = 12.sp) }
                                        Icon(Icons.Default.ChevronRight, null, tint = Purple)
                                    }
                                }
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("SUA BIBLIOTECA", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
                            Text("${allTracks.size} faixas", color = Cyan, fontSize = 12.sp)
                            IconButton(onClick = { loading = true; allTracks = scanMedia(); if (selectedPlaylist == "Todas as músicas") queue = allTracks; loading = false }) { Icon(Icons.Default.Refresh, "Atualizar biblioteca", tint = Cyan) }
                        }
                        OutlinedTextField(
                            value = musicSearch,
                            onValueChange = { musicSearch = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Pesquisar música ou artista", color = Color.Gray) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Pesquisar", tint = Cyan) },
                            singleLine = true,
                            shape = RoundedCornerShape(18.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF39405A), focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan)
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box { OutlinedButton(onClick = { showPlaylistMenu = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Icon(Icons.Default.QueueMusic, null); Spacer(Modifier.width(6.dp)); Text(selectedPlaylist, maxLines = 1) }; DropdownMenu(expanded = showPlaylistMenu, onDismissRequest = { showPlaylistMenu = false }) { playlistNames.forEach { name -> DropdownMenuItem(text = { Text(name) }, onClick = { selectedPlaylist = name; showPlaylistMenu = false; playList(if (name == "Todas as músicas") allTracks else visibleTracks) }) } }
                            }
                            Spacer(Modifier.width(6.dp)); FilledTonalButton(onClick = { showNewPlaylist = true }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF183747), contentColor = Cyan)) { Icon(Icons.Default.Add, null); Text("Playlist") }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (visibleTracks.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.LibraryMusic, null, tint = Purple, modifier = Modifier.size(50.dp)); Spacer(Modifier.height(10.dp)); Text(if (allTracks.isEmpty()) "Nenhuma música encontrada" else "Playlist vazia", color = Color.White, fontWeight = FontWeight.Bold); Text("Permita o acesso aos arquivos e toque em atualizar.", color = Color.LightGray, fontSize = 12.sp) } }
                        } else {
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                itemsIndexed(if (selectedPlaylist == "Todas as músicas") queue else visibleTracks, key = { _, track -> track.uri.toString() }) { index, track ->
                                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (track.uri == currentTrack?.uri) Color(0xFF183343) else Panel).clickable { if (selectedPlaylist == "Todas as músicas") playList(queue, index) else playList(visibleTracks, index); currentScreen = "player" }.padding(horizontal = 10.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(Color(0xFF1A3152), Color(0xFF24133F)))), contentAlignment = Alignment.Center) { Icon(if (track.video) Icons.Default.Movie else Icons.Default.MusicNote, null, tint = if (track.uri == currentTrack?.uri) Cyan else Purple, modifier = Modifier.size(26.dp)) }
                                        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Color.LightGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                        IconButton(onClick = { trackForPlaylist = track; showAddToPlaylist = true }) { Icon(Icons.Default.PlaylistAdd, "Adicionar à playlist", tint = Cyan) }
                                        Column { IconButton(onClick = { reorder(index, index - 1) }, enabled = index > 0, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.KeyboardArrowUp, "Mover para cima", tint = Color.LightGray) }; IconButton(onClick = { reorder(index, index + 1) }, enabled = index < queue.lastIndex, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.KeyboardArrowDown, "Mover para baixo", tint = Color.LightGray) } }
                                    }
                                }
                            }
                        }
                        Card(Modifier.fillMaxWidth().clickable { currentScreen = "player" }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xEE151B2D))) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(48.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(Cyan, Purple))), contentAlignment = Alignment.Center) { if (artwork != null) Image(artwork!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Icon(Icons.Default.Album, null, tint = Night) }
                                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(currentTrack?.title ?: "Escolha uma música", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(currentTrack?.artist ?: "Neon Wave", color = Cyan, fontSize = 11.sp) }
                                IconButton(onClick = { controller?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                                IconButton(onClick = { if (playing) controller?.pause() else controller?.play() }, modifier = Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Cyan, Purple)))) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Night) }
                                IconButton(onClick = { controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                            }
                        }
                    }
                    NavigationBar(containerColor = Color(0xEE101626), tonalElevation = 0.dp, modifier = Modifier.height(62.dp)) {
                        NavigationBarItem(selected = currentScreen == "home", onClick = { currentScreen = "home" }, icon = { Icon(Icons.Default.MusicNote, null) }, label = { Text("Músicas") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF183343), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                        NavigationBarItem(selected = currentScreen == "playlists", onClick = { currentScreen = "playlists" }, icon = { Icon(Icons.Default.QueueMusic, null) }, label = { Text("Playlists") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF183343), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                        NavigationBarItem(selected = currentScreen == "player", onClick = { currentScreen = "player" }, icon = { Icon(Icons.Default.GraphicEq, null) }, label = { Text("Player") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF183343), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                    }
                    Spacer(Modifier.height(5.dp)); Text("Desenvolvido por Meg", color = Color(0xFF7F8CA8), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
    }
    if (showLyrics) AlertDialog(
        onDismissRequest = { showLyrics = false },
        title = { Text("Letras da música") },
        text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
            Text(currentTrack?.title ?: "Nenhuma música", color = Cyan, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(lyricsText ?: "Ainda não encontrei a letra localmente nem no LRCLIB. Confira a conexão e tente novamente mais tarde.", color = Color.White)
        } },
        confirmButton = {
            Row {
                TextButton(onClick = {
                    val track = currentTrack
                    if (track != null) {
                        lyricsSearching = true
                        kotlinx.coroutines.CoroutineScope(Dispatchers.Main).launch {
                            lyricsText = withContext(Dispatchers.IO) { findOnlineLyrics(context, track) }
                            lyricsSearching = false
                        }
                    }
                }, enabled = !lyricsSearching) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(4.dp)); Text(if (lyricsSearching) "Buscando…" else "Buscar na internet") }
                TextButton(onClick = { showLyrics = false }) { Text("Fechar") }
            }
        }
    )
    if (showEqualizerInfo) AlertDialog(onDismissRequest = { showEqualizerInfo = false }, title = { Text("Equalizador indisponível") }, text = { Text("Este aparelho não disponibilizou um painel de equalizador do sistema. Se houver um equalizador instalado no Android, ele poderá aparecer aqui.") }, confirmButton = { TextButton(onClick = { showEqualizerInfo = false }) { Text("OK") } })

    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Configurações") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Papel de parede", fontWeight = FontWeight.Bold); Button(onClick = { wallpaperPicker.launch(arrayOf("image/*")) }) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Escolher imagem") }
            if (wallpaper != null) TextButton(onClick = { wallpaper = null; prefs.edit().remove("wallpaper").apply() }) { Text("Remover papel de parede") }
            Text("Opacidade: ${(wallpaperOpacity * 100).toInt()}%"); Slider(value = wallpaperOpacity, onValueChange = { wallpaperOpacity = it; prefs.edit().putFloat("wallpaper_opacity", it).apply() }, valueRange = 0f..1f)
            Text("A biblioteca procura automaticamente músicas de áudio e vídeos MP4 disponíveis no armazenamento do aparelho.", fontSize = 12.sp)
        }
    }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Fechar") } })
    if (showNewPlaylist) AlertDialog(onDismissRequest = { showNewPlaylist = false }, title = { Text("Nova playlist") }, text = { OutlinedTextField(value = newPlaylistName, onValueChange = { newPlaylistName = it }, label = { Text("Nome da playlist") }, singleLine = true) }, confirmButton = { TextButton(onClick = { val name = newPlaylistName.trim(); if (name.isNotEmpty() && name !in playlistNames) { playlistNames = playlistNames + name; playlists = playlists + (name to emptyList<String>()); selectedPlaylist = name }; newPlaylistName = ""; showNewPlaylist = false }) { Text("Criar") } }, dismissButton = { TextButton(onClick = { showNewPlaylist = false }) { Text("Cancelar") } })
    if (showAddToPlaylist) AlertDialog(onDismissRequest = { showAddToPlaylist = false }, title = { Text("Adicionar à playlist") }, text = { Column { playlistNames.filter { it != "Todas as músicas" }.forEach { name -> TextButton(onClick = { val track = trackForPlaylist; if (track != null) playlists = playlists + (name to ((playlists[name] ?: emptyList<String>()) + track.uri.toString()).distinct()); showAddToPlaylist = false }) { Icon(Icons.Default.PlaylistAdd, null); Spacer(Modifier.width(8.dp)); Text(name) } }; if (playlistNames.size <= 1) Text("Crie uma playlist primeiro.") } }, confirmButton = { TextButton(onClick = { showAddToPlaylist = false }) { Text("Fechar") } })
}
