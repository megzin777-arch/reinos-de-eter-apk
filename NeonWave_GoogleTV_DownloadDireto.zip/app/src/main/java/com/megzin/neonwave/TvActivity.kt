package com.megzin.neonwave

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.app.DownloadManager
import android.content.Context
import android.os.Environment
import android.widget.Toast
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.net.URLEncoder

private val NeonBg = Color(0xFF090910)
private val NeonPanel = Color(0xFF171724)
private val TvNeonCyan = Color(0xFF00E5FF)
private val TvNeonPurple = Color(0xFF8A2BE2)

private data class TvTrack(val id: Long, val title: String, val artist: String, val uri: Uri)

class TvActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var tracksState = mutableStateListOf<TvTrack>()

    private val requestAudioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadTracks()
    }
    private val pickMusicFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try {
                contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                getSharedPreferences("neon_wave_tv", MODE_PRIVATE).edit().putString("music_folder", treeUri.toString()).apply()
            } catch (_: Exception) { }
            loadTracks()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build().apply { repeatMode = Player.REPEAT_MODE_OFF }
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadTracks()
        else requestAudioPermission.launch(permission)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = TvNeonCyan, secondary = TvNeonPurple, background = NeonBg,
                surface = NeonPanel, onBackground = Color.White, onSurface = Color.White
            )) {
                TvHomeScreen(tracks = tracksState, onPlay = { track ->
                    player?.setMediaItem(MediaItem.fromUri(track.uri)); player?.prepare(); player?.play()
                }, onSearchYouTube = { query -> openYouTubeSearch(query) }, onImportFolder = { pickMusicFolder.launch(null) }, onDownloadUrl = { url -> downloadAudio(url) })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Atualiza a biblioteca ao voltar para o app, por exemplo após conectar um pendrive.
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadTracks()
    }

    private fun loadTracks() {
        val found = linkedMapOf<String, TvTrack>()
        // First try Android's media library for ordinary indexed tracks.
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    found[uri.toString()] = TvTrack(uri.toString().hashCode().toLong(), cursor.getString(titleCol) ?: "Faixa sem título", cursor.getString(artistCol) ?: "Artista desconhecido", uri)
                }
            }
        } catch (_: Exception) { }

        // Also scan the folder explicitly chosen by the user, including USB/Downloads folders
        // that Android TV may not index in MediaStore.
        val savedTree = getSharedPreferences("neon_wave_tv", MODE_PRIVATE).getString("music_folder", null)
        if (savedTree != null) {
            try { scanTree(Uri.parse(savedTree), found, 0) } catch (_: Exception) { }
        }
        tracksState.clear()
        tracksState.addAll(found.values.sortedBy { it.title.lowercase() })
    }

    private fun scanTree(treeUri: Uri, found: MutableMap<String, TvTrack>, depth: Int) {
        if (depth > 12) return
        val documentId = DocumentsContract.getTreeDocumentId(treeUri)
        val rootDocument = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
        scanDocument(treeUri, rootDocument, found, depth)
    }

    private fun scanDocument(treeUri: Uri, documentUri: Uri, found: MutableMap<String, TvTrack>, depth: Int) {
        if (depth > 12) return
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE)
        try {
            contentResolver.query(documentUri, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (cursor.moveToNext()) {
                    val id = cursor.getString(idCol) ?: continue
                    val name = cursor.getString(nameCol) ?: "Arquivo de áudio"
                    val mime = cursor.getString(mimeCol) ?: ""
                    val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, id)
                        scanChildren(treeUri, childrenUri, found, depth + 1)
                    } else if (mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in setOf("mp3", "m4a", "aac", "ogg", "opus", "flac", "wav", "wma", "mp4")) {
                        found[childUri.toString()] = TvTrack(childUri.toString().hashCode().toLong(), name.substringBeforeLast('.', name), "Pasta importada", childUri)
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun scanChildren(treeUri: Uri, childrenUri: Uri, found: MutableMap<String, TvTrack>, depth: Int) {
        if (depth > 12) return
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE)
        try {
            contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (cursor.moveToNext()) {
                    val id = cursor.getString(idCol) ?: continue
                    val name = cursor.getString(nameCol) ?: "Arquivo de áudio"
                    val mime = cursor.getString(mimeCol) ?: ""
                    val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        scanChildren(treeUri, DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, id), found, depth + 1)
                    } else if (mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in setOf("mp3", "m4a", "aac", "ogg", "opus", "flac", "wav", "wma", "mp4")) {
                        found[uri.toString()] = TvTrack(uri.toString().hashCode().toLong(), name.substringBeforeLast('.', name), "Pasta importada", uri)
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun downloadAudio(rawUrl: String) {
        val uri = try { Uri.parse(rawUrl.trim()) } catch (_: Exception) { null }
        if (uri == null || uri.scheme !in listOf("https", "http") || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Cole um link direto para um arquivo de áudio.", Toast.LENGTH_LONG).show(); return
        }
        if (uri.host!!.contains("youtube.com", true) || uri.host!!.contains("youtu.be", true)) {
            Toast.makeText(this, "Links do YouTube não são links diretos de áudio. Use fontes que autorizem o download.", Toast.LENGTH_LONG).show(); return
        }
        val path = uri.lastPathSegment.orEmpty()
        val ext = path.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("mp3", "m4a", "aac", "ogg", "opus", "flac", "wav", "mp4", "webm")) {
            Toast.makeText(this, "O link precisa apontar diretamente para um arquivo de áudio compatível.", Toast.LENGTH_LONG).show(); return
        }
        try {
            val request = DownloadManager.Request(uri)
                .setTitle(path.ifBlank { "Música" })
                .setDescription("Baixando para o Neon Wave")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "NeonWave/${path.ifBlank { "musica.$ext" }}")
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Download iniciado. A faixa aparecerá na biblioteca quando terminar.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível iniciar o download desse link.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openYouTubeSearch(query: String) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val uri = Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable
private fun TvHomeScreen(tracks: List<TvTrack>, onPlay: (TvTrack) -> Unit, onSearchYouTube: (String) -> Unit, onImportFolder: () -> Unit, onDownloadUrl: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showDownloadDialog by remember { mutableStateOf(false) }
    var downloadUrl by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Tudo") }
    val filtered = remember(tracks, query) {
        if (query.isBlank()) tracks else tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    }
    Row(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10101B), NeonBg))).padding(horizontal = 34.dp, vertical = 24.dp)) {
        Column(Modifier.width(210.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(TvNeonCyan, TvNeonPurple))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color.Black)
                }
                Column {
                    Text("NEON WAVE", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("MUSIC FOR YOUR TV", fontSize = 9.sp, color = TvNeonCyan, letterSpacing = 1.5.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            listOf("Tudo", "YouTube", "Músicas locais").forEach { tab ->
                TvNavItem(label = tab, selected = selectedTab == tab, onClick = { selectedTab = tab })
            }
            Spacer(Modifier.weight(1f))
            Text("Use as setas e OK", color = Color(0xFF77778A), fontSize = 12.sp)
        }
        Spacer(Modifier.width(26.dp))
        Column(Modifier.fillMaxSize()) {
            Text("Sua música, do seu jeito.", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Pesquise no YouTube ou encontre arquivos nesta TV.", fontSize = 14.sp, color = Color(0xFFAAAABD), modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
                singleLine = true,
                placeholder = { Text("Buscar música, artista ou álbum", color = Color(0xFF8B8B9E)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar", tint = TvNeonCyan) },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = TvNeonCyan, unfocusedBorderColor = Color(0xFF353548), focusedContainerColor = NeonPanel, unfocusedContainerColor = NeonPanel)
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvActionButton("Pesquisar no YouTube", selectedTab == "YouTube" || selectedTab == "Tudo", Modifier.weight(1f)) { if (query.isNotBlank()) onSearchYouTube(query) }
                TvActionButton("Mostrar arquivos locais", selectedTab == "Músicas locais" || selectedTab == "Tudo", Modifier.weight(1f)) { selectedTab = "Músicas locais" }
            }
            Spacer(Modifier.height(10.dp))
            TvActionButton("Importar pasta com músicas", true, Modifier.fillMaxWidth(), onImportFolder)
            Spacer(Modifier.height(8.dp))
            TvActionButton("Baixar música por link direto", true, Modifier.fillMaxWidth()) { showDownloadDialog = true }
            Spacer(Modifier.height(18.dp))
            Text(if (selectedTab == "YouTube") "PESQUISA ONLINE" else "BIBLIOTECA LOCAL  •  ${filtered.size} FAIXAS", color = TvNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            if (selectedTab == "YouTube") {
                Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(18.dp)).background(NeonPanel).padding(24.dp), contentAlignment = Alignment.CenterStart) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Abra a pesquisa oficial do YouTube", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Digite acima e selecione ‘Pesquisar no YouTube’. O conteúdo será aberto no app do YouTube, se instalado, ou no navegador.", color = Color(0xFFB8B8C9), fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        TvActionButton("Buscar agora", true) { if (query.isNotBlank()) onSearchYouTube(query) }
                    }
                }
            } else {
                val shown = if (selectedTab == "Músicas locais" || selectedTab == "Tudo") filtered else emptyList()
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text(if (query.isBlank()) "Nenhuma música local encontrada. Conecte um pendrive ou permita o acesso à mídia." else "Nenhuma música local corresponde à busca.", color = Color(0xFFB8B8C9), fontSize = 15.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                        items(shown, key = { it.id }) { track ->
                            TvTrackRow(track, onClick = { onPlay(track) })
                        }
                    }
                }
            }
        }
    }
    if (showDownloadDialog) {
        AlertDialog(
            onDismissRequest = { showDownloadDialog = false },
            title = { Text("Baixar música") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cole o link direto de um arquivo MP3, M4A, AAC, OGG, FLAC ou WAV de uma fonte que permita o download. Links de pesquisa do YouTube não funcionam aqui.", color = Color(0xFFB8B8C9), fontSize = 13.sp)
                    OutlinedTextField(value = downloadUrl, onValueChange = { downloadUrl = it }, label = { Text("Link direto do arquivo") }, singleLine = true)
                }
            },
            confirmButton = { TextButton(onClick = { val value = downloadUrl.trim(); if (value.isNotBlank()) { onDownloadUrl(value); showDownloadDialog = false } }) { Text("Baixar") } },
            dismissButton = { TextButton(onClick = { showDownloadDialog = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun TvNavItem(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(if (selected || focused) Color(0xFF20283A) else Color.Transparent)
        .border(if (focused) 2.dp else 1.dp, if (focused) TvNeonCyan else if (selected) Color(0xFF45405D) else Color.Transparent, RoundedCornerShape(13.dp))
        .onFocusChanged { focused = it.isFocused }.focusable().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = if (selected || focused) TvNeonCyan else Color(0xFFB8B8C9), fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp)
    }
}

@Composable
private fun TvActionButton(label: String, primary: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Button(onClick = onClick, modifier = modifier.heightIn(min = 48.dp).onFocusChanged { focused = it.isFocused }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = if (primary) TvNeonPurple else Color(0xFF252536), contentColor = Color.White), border = if (focused) androidx.compose.foundation.BorderStroke(2.dp, TvNeonCyan) else null, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)) {
        Text(label, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TvTrackRow(track: TvTrack, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(if (focused) Color(0xFF22263A) else Color(0x66171724))
        .border(if (focused) 2.dp else 1.dp, if (focused) TvNeonCyan else Color(0x22353548), RoundedCornerShape(13.dp))
        .onFocusChanged { focused = it.isFocused }.focusable().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(TvNeonPurple, Color(0xFF24243A)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = TvNeonCyan)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(track.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Color(0xFFAAAABD), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onClick) { Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir ${track.title}", tint = TvNeonCyan) }
    }
}
