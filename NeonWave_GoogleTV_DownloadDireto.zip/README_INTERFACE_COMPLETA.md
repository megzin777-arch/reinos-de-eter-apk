# Neon Wave — Interface integrada

Projeto Android Kotlin com Jetpack Compose/Material 3, Media3 e componentes separados por arquivo.

## Interface
- Player principal com capa, barra de progresso ligada à posição do MediaController, shuffle, repetição, anterior/próxima e play/pause.
- Biblioteca com pesquisa e mini-player, lista de faixas e ações de playlist.
- Tela de playlists e diálogos para criar/adicionar faixas.
- Letras locais e consulta online ao LRCLIB, com ação de nova busca.
- Configurações de papel de parede e opacidade.
- Paleta escura Neon Wave (quase preto, ciano e roxo).

## Abrir
Extraia o ZIP, abra a pasta `NeonWave` na IDE Android e sincronize o Gradle. Requer acesso à internet para baixar dependências na primeira compilação e consultar letras online.

## Observação de validação
O ZIP é verificado estruturalmente, mas a compilação Android não pôde ser executada neste ambiente por indisponibilidade de acesso a `services.gradle.org`. Não é correto prometer compilação validada sem rodar o Gradle.
