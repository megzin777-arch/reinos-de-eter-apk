package com.neonwave.bootstrap;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.Enumeration;

/** Small, project-local bootstrapper used because the uploaded project had no Gradle Wrapper. */
public final class GradleBootstrap {
    private static final String VERSION = "8.9";
    private static final String ZIP_NAME = "gradle-" + VERSION + "-bin.zip";
    private static final String URL_TEXT = "https://services.gradle.org/distributions/" + ZIP_NAME;
    private static final String EXPECTED_SHA256 = "d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab";

    private GradleBootstrap() {}

    public static void main(String[] args) {
        try {
            File userHome = getGradleUserHome();
            File cache = new File(userHome, "wrapper/dists/neonwave-gradle-" + VERSION);
            ensureDirectory(cache);
            File install = new File(cache, "gradle-" + VERSION);
            File gradleExec = new File(install, isWindows() ? "bin/gradle.bat" : "bin/gradle");
            File marker = new File(cache, ".verified-sha256");

            if (!isUsableInstall(gradleExec, marker)) {
                installDistribution(cache, install, marker);
                gradleExec = new File(install, isWindows() ? "bin/gradle.bat" : "bin/gradle");
            }
            if (!isWindows()) gradleExec.setExecutable(true, true);
            runGradle(gradleExec, args);
        } catch (Exception e) {
            System.err.println("Neon Wave Gradle bootstrap failed: " + e.getMessage());
            System.err.println("Check internet access, free storage, Java/JDK configuration, and retry.");
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    private static File getGradleUserHome() {
        String env = System.getenv("GRADLE_USER_HOME");
        if (env != null && !env.trim().isEmpty()) return new File(env);
        String home = System.getProperty("user.home");
        if (home == null || home.trim().isEmpty()) home = ".";
        return new File(home, ".gradle");
    }

    private static boolean isUsableInstall(File gradleExec, File marker) throws IOException {
        if (!gradleExec.isFile()) return false;
        if (isWindows()) return marker.isFile() && readText(marker).trim().equals(EXPECTED_SHA256);
        return marker.isFile() && readText(marker).trim().equals(EXPECTED_SHA256);
    }

    private static void installDistribution(File cache, File install, File marker) throws Exception {
        File zip = new File(cache, ZIP_NAME + ".part");
        File staging = new File(cache, ".extracting");
        deleteRecursively(staging);
        deleteRecursively(install);
        if (zip.exists() && !zip.delete()) throw new IOException("Cannot remove incomplete download: " + zip);
        System.out.println("Neon Wave: downloading Gradle " + VERSION + " (about 130 MB) ...");
        downloadAndVerify(zip);
        ensureDirectory(staging);
        System.out.println("Neon Wave: unpacking Gradle ...");
        unzipSafely(zip, staging);
        File unpacked = new File(staging, "gradle-" + VERSION);
        if (!new File(unpacked, isWindows() ? "bin/gradle.bat" : "bin/gradle").isFile()) {
            throw new IOException("Downloaded Gradle archive did not contain the expected executable");
        }
        if (!unpacked.renameTo(install)) {
            copyRecursively(unpacked, install);
            deleteRecursively(unpacked);
        }
        writeText(marker, EXPECTED_SHA256 + System.lineSeparator());
        deleteRecursively(staging);
        if (zip.exists() && !zip.delete()) System.err.println("Warning: could not remove temporary Gradle ZIP");
        System.out.println("Neon Wave: Gradle " + VERSION + " is ready.");
    }

    private static void downloadAndVerify(File destination) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(URL_TEXT);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(180000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "NeonWave-Gradle-Bootstrap/1.0");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("Download server returned HTTP " + status);
            long total = connection.getContentLengthLong();
            long written = 0;
            int lastPercent = -1;
            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
                byte[] buffer = new byte[128 * 1024];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    out.write(buffer, 0, count);
                    written += count;
                    if (total > 0) {
                        int percent = (int) Math.min(100, written * 100 / total);
                        if (percent / 5 != lastPercent / 5) {
                            System.out.println("Download: " + percent + "%");
                            lastPercent = percent;
                        }
                    }
                }
            }
            String actual = sha256(destination);
            if (!EXPECTED_SHA256.equalsIgnoreCase(actual)) {
                destination.delete();
                throw new IOException("Gradle ZIP SHA-256 mismatch; the incomplete or altered file was deleted");
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static void unzipSafely(File zip, File destination) throws IOException {
        String base = destination.getCanonicalPath() + File.separator;
        try (ZipFile archive = new ZipFile(zip)) {
            Enumeration<? extends ZipEntry> entries = archive.entries();
            byte[] buffer = new byte[65536];
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                File outFile = new File(destination, entry.getName());
                String canonical = outFile.getCanonicalPath();
                if (!canonical.startsWith(base)) throw new IOException("Unsafe path in Gradle archive");
                if (entry.isDirectory()) {
                    ensureDirectory(outFile);
                } else {
                    File parent = outFile.getParentFile();
                    if (parent != null) ensureDirectory(parent);
                    try (InputStream in = new BufferedInputStream(archive.getInputStream(entry));
                         BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile))) {
                        int count;
                        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                    }
                }
            }
        }
    }

    private static void runGradle(File gradleExec, String[] args) throws Exception {
        List<String> command = new ArrayList<String>();
        if (isWindows()) {
            command.add("cmd.exe"); command.add("/c"); command.add("call"); command.add(gradleExec.getAbsolutePath());
        } else {
            command.add(gradleExec.getAbsolutePath());
        }
        for (String arg : args) command.add(arg);
        System.out.println("Neon Wave: running Gradle " + VERSION + " ...");
        Process process = new ProcessBuilder(command).directory(new File(System.getProperty("user.dir"))).inheritIO().start();
        int code = process.waitFor();
        if (code != 0) System.exit(code);
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }
    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) {
            byte[] b = new byte[128 * 1024]; int n;
            while ((n = in.read(b)) != -1) digest.update(b, 0, n);
        }
        StringBuilder out = new StringBuilder();
        for (byte b : digest.digest()) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return out.toString();
    }
    private static void ensureDirectory(File dir) throws IOException {
        if (dir.isDirectory()) return;
        if (!dir.mkdirs() && !dir.isDirectory()) throw new IOException("Cannot create directory: " + dir);
    }
    private static String readText(File file) throws IOException {
        byte[] b = Files.readAllBytes(file.toPath());
        return new String(b, StandardCharsets.UTF_8);
    }
    private static void writeText(File file, String value) throws IOException {
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(value.getBytes(StandardCharsets.UTF_8)); }
    }
    private static void copyRecursively(File from, File to) throws IOException {
        if (from.isDirectory()) {
            ensureDirectory(to);
            File[] children = from.listFiles();
            if (children != null) for (File child : children) copyRecursively(child, new File(to, child.getName()));
        } else {
            File parent = to.getParentFile(); if (parent != null) ensureDirectory(parent);
            try (InputStream in = new FileInputStream(from); FileOutputStream out = new FileOutputStream(to)) {
                byte[] b = new byte[65536]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n);
            }
        }
    }
    private static void deleteRecursively(File file) throws IOException {
        if (!file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        if (!file.delete()) throw new IOException("Cannot delete temporary path: " + file);
    }
}
