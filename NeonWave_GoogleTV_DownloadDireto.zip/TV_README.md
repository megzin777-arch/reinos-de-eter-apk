# Neon Wave — edição para Google TV / Android TV

Esta edição mantém a atividade de celular existente e adiciona uma atividade exclusiva para TV, publicada no launcher de Android TV/Google TV.

## O que foi adicionado
- Interface paisagem, com identidade visual preto/ciano/roxo e elementos grandes para navegação por controle remoto.
- Pesquisa de arquivos de áudio locais usando o catálogo de mídia do Android.
- Campo de busca e ação para abrir a pesquisa oficial do YouTube em `youtube.com/results?search_query=...`. Se o app do YouTube estiver instalado, o Android poderá oferecer/usar esse app; caso contrário, abre um navegador compatível.
- Reprodução local básica com ExoPlayer durante a sessão da tela de TV.
- Declarações de suporte a Leanback e touchscreen opcional, e categoria `LEANBACK_LAUNCHER` para aparecer na interface de TV.

## Limitações conhecidas
- A busca do YouTube abre a página oficial; não usa a YouTube Data API e não exibe os resultados dentro do Neon Wave. Isso evita exigir uma chave de API nesta primeira versão.
- O app do YouTube/navegador e as regras da plataforma controlam a reprodução online. Não há extração de áudio.
- A atividade de TV tem reprodução local em primeiro plano, mas ainda não está conectada ao serviço Media3 já existente para continuar tocando ao sair da tela.
- A permissão de mídia é solicitada ao iniciar a atividade; arquivos indisponíveis ou não indexados pelo sistema não aparecerão.
- A navegação foi estruturada para D-pad; teste na TV real para validar foco e escala.

## Instalação e teste
1. Abra o projeto na IDE Android.
2. Compile `assembleDebug` como no projeto original.
3. Instale o APK na Google TV. Se a IDE não permitir instalação direta, transfira o APK e instale usando um método de sideload autorizado nas configurações da TV.
4. Abra **Neon Wave TV** no launcher da TV. Dependendo da launcher, a atividade Leanback pode aparecer como uma segunda entrada com o mesmo nome.

A alteração não foi compilada neste ambiente. Compile na mesma IDE que já funcionou no seu dispositivo e envie o erro caso apareça algum.
