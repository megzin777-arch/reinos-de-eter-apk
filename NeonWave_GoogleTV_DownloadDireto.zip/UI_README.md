# Neon Wave UI – Jetpack Compose

Este pacote adiciona componentes de interface reutilizáveis ao projeto existente.

## Arquivos
- `Theme.kt`: cores e tema escuro Neon Wave.
- `PlayerScreen.kt`: tela principal “Tocando Agora”, slider e controles de demonstração.
- `TrackListItem.kt`: item para listas de músicas com selo LETRA.
- `MiniPlayer.kt`: mini-player reutilizável.
- `PlaylistScreen.kt`: cards de playlists e ação para criar.
- `LyricsScreen.kt`: estado sem letras, botão para adicionar e ação para pesquisar na web.
- `ThemeSettingsScreen.kt`: seletor de modo e cor de destaque.

## Dependências adicionadas
- Coil Compose 2.7.0
- Navigation Compose 2.8.5

## Integração
Os composables são componentes de UI separados. Para usar a tela A no `setContent`, envolva a tela com `NeonWaveTheme { PlayerScreen(...) }` e conecte callbacks ao `MediaController` e à navegação do aplicativo.

Os controles desta tela demonstrativa usam estado local para ilustrar a interface. Shuffle, repeat, play/pause, barra de progresso e botões de navegação precisam ser ligados ao player Media3 existente para controlar o áudio real. A busca web de letras deve ser conectada ao fluxo de pesquisa escolhido no aplicativo.

A imagem de capa usa Coil com `artworkUrl`; para capas locais, passe uma URI ou caminho compatível com Coil. Se for nulo, o espaço da capa permanece como placeholder escuro.
